import { Component } from '@angular/core';
import { RouterOutlet } from '@angular/router';
import { SquareComponent } from './components/square/square.component';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { BoardComponent } from './pages/board/board.component';
import { GameComponent } from './pages/game/game.component';
import { Game } from './services/game';
import { GameService } from './services/game.service';
import { PongComponent } from './pages/pong/pong.component';


@Component({
  selector: 'app-root',
  standalone: true,
  imports: [RouterOutlet, HeaderComponent, FooterComponent, BoardComponent, SquareComponent, GameComponent, PongComponent],
  templateUrl: './app.component.html',
  styleUrl: './app.component.scss'
})

export class AppComponent {
  
  game?: Game

  constructor(private gameService: GameService){}

  ngOnInit() {
    this.gameService.getGame().subscribe(game =>{
      this.game = game;
    })
  }

  goal(player: boolean) {
    this.gameService.goal(player ? 1 : 2);
  }

}
