import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: 'board',
    loadComponent: () => import('./pages/board/board.component').then(m => m.BoardComponent)
  },
  {
    path: 'pong',
    loadComponent: () => import('./pages/pong/pong.component').then(m => m.PongComponent)
  },
  {
    path: '',
    redirectTo: 'board',
    pathMatch: 'full'
  }
];
