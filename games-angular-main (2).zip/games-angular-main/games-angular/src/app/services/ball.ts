export interface Ball {
    x_position: number;
    y_position: number;
    size: number;
    color: string;
  }
  