export interface Player {
    points: number;
    x_position: number;
    y_position: number;
    y_direction: number;
    width: number;
    height: number;
    color: string;
  }
  