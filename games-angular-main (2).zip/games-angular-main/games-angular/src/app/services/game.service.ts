import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { Game } from './game';
import { Player } from './player';
import { Ball } from './ball';

@Injectable({
  providedIn: 'root',
})
export class GameService {
  private gameSubject: BehaviorSubject<Game>;
  public game$: Observable<Game>;
  isGaming = true;
  isPaused = false;
  isRestarted = false;

  constructor() {
    const player1: Player = {
      points: 0,
      x_position: -250,
      y_position: 300,
      y_direction: 0,
      width: 10,
      height: 100,
      color: 'blue',
    };

    const player2: Player = {
      points: 0,
      x_position: 250,
      y_position: 300,
      y_direction: 0,
      width: 10,
      height: 100,
      color: '#1ff30c',
    };

    const ball: Ball = {
      x_position: 0,
      y_position: 200,
      size: 25,
      color: 'red',
    };

    const game: Game = {
      player1: player1,
      player2: player2,
      ball: ball,
    };

    this.gameSubject = new BehaviorSubject(game);
    this.game$ = this.gameSubject.asObservable();
  }

  setState() {
    this.isPaused = !this.isPaused;
  }

  getGame(): Observable<Game> {
    return this.game$;
  }

  movePlayer(player: number, position: number) {
    const game = this.gameSubject.getValue(); 
    if (player === 1) {
      game.player1.y_position = position;
    } else {
      game.player2.y_position = position;
    }
    this.gameSubject.next(game); 
  }

  goal(player: number) {
    const game = this.gameSubject.getValue(); 
    if (this.isGaming) {
      this.isGaming = false; 
  
      if (player === 1) {

        game.player1.points += 1;
      } else {
   
        game.player2.points += 1;
      }
  
      this.gameSubject.next(game); 
      this.restart();
    }
  }
  
  


  checkWall(top: number, bottom: number, player: number): boolean {
    const game = this.gameSubject.getValue();
    const tempP: Player = player === 1 ? game.player1 : game.player2;
    return (
    
      tempP &&
      ((top >= tempP.y_position - tempP.height && top < tempP.y_position) ||
        (bottom > tempP.y_position - tempP.height &&
          bottom <= tempP.y_position))
    );
  }

  reset() {
    this.isRestarted = true;
    this.isPaused = true;

    const game = this.gameSubject.getValue(); 
    game.player1.points = 0;
    game.player1.y_direction = 0;
    game.player1.y_position = 300;

    game.player2.points = 0;
    game.player2.y_direction = 0;
    game.player2.y_position = 300;

    game.ball.x_position = 0;
    game.ball.y_position = 200;

    this.gameSubject.next(game); 

    this.restart();
  }

  async restart() {
    await new Promise((f) => setTimeout(f, 6));
    this.isPaused = false;
    this.isRestarted = false;
    this.isGaming = true;
  }
}
