import { Component } from '@angular/core';
import { Game } from '../../services/game';
import { Observable } from 'rxjs';
import { GameService } from '../../services/game.service';
import { GameComponent } from '../game/game.component';
import { CommonModule } from '@angular/common'; 

@Component({
  selector: 'app-pong',
  templateUrl: './pong.component.html',
  styleUrls: ['./pong.component.scss'],
  standalone: true,
  imports: [CommonModule, GameComponent], 
})
export class PongComponent {
  game$: Observable<Game | null>;

  // valor padrão que será usado caso game$ seja null
  defaultGame: Game = {
    player1: {
      points: 0,
      x_position: -250,
      y_position: 300,
      y_direction: 0,
      width: 10,
      height: 100,
      color: '#ee82ee',
    },

    player2: {
      points: 0,
      x_position: 250,
      y_position: 300,
      y_direction: 0,
      width: 10,
      height: 100,
      color: '#ee82ee',
    },

    ball: {
       x_position: 0, 
       y_position: 200,
       size: 25,
       color: '#ee82ee' 
      },
  };

  constructor(private gameService: GameService) {
    this.game$ = this.gameService.getGame();
  }

  goal(event: any) {
    this.gameService.goal(event);
  }
}
